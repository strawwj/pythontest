import turtle 
from func_test import func1
turtle.color("red","red")
turtle.forward(300)
