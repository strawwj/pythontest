#conding:utf-8
a =int(input("please input no."))
b = int(input("please input no."))
c = a+b
d = a -b
e = a*b
f = a/b
print(c,d,e,f)
